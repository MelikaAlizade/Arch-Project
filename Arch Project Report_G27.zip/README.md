# Seminar Template

A LaTeX template for typesetting Seminar in Persian.

By: Zeinab Seifoori
